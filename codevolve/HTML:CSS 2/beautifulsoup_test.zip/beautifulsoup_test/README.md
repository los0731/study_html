# beautifulsoup_exercise
